#include "Controller.h"

int main()
{
	Controller game;
	game.run();
}
